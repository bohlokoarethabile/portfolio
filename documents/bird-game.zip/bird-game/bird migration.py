#bird migration
import pygame, os, random, sys, time

#initialization for all pygame modules
pygame.init() 
try:
    pygame.mixer.init() # incase the sound system fails we initializes the mixe
except pygame.error:
    print("Audio could not be initialized.")

# Screen Setup using weidth and height
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Bird Migration")
clock = pygame.time.Clock() # to be able to control how long the screen should last.

# asset folder setup
BASE_DIR = os.path.dirname(__file__) #location of the folder "bird migration_game" 
ASSETS_DIR = os.path.join(BASE_DIR, "assets")
SOUNDS_DIR = os.path.join(BASE_DIR, "sounds")

#loading images from the file by resizing all of the images
def load_image(path, size=None):
    try:
        img = pygame.image.load(path)
        if size:
            img = pygame.transform.scale(img, size)
        return img
    except pygame.error: # if file not found return a palceholder surface (red)
        surf = pygame.Surface(size or (50, 50))
        surf.fill((200, 50, 50))
        return surf

# if the file found load required png images from the assest folder
menu_image = load_image(os.path.join(ASSETS_DIR, "menu_screen.png"), (WIDTH, HEIGHT))
background_img = load_image(os.path.join(ASSETS_DIR, "background.png"), (WIDTH, HEIGHT))
bird_img = load_image(os.path.join(ASSETS_DIR, "bird.png"), (50, 50))
tail_img = load_image(os.path.join(ASSETS_DIR, "bird.png"), (30, 30))
feather_img = load_image(os.path.join(ASSETS_DIR, "feather.png"), (30, 30))
powerup_img = load_image(os.path.join(ASSETS_DIR, "powerup.png"), (30, 30))
freeze_img = load_image(os.path.join(ASSETS_DIR, "freeze.png"), (30, 30))
obstacle_img = load_image(os.path.join(ASSETS_DIR, "obstacle.png"), (40, 40))
logo_img = load_image(os.path.join(ASSETS_DIR, "crystal.png"), (80, 80))
asteroid_img = load_image(os.path.join(ASSETS_DIR, "asteroid.png"), (60, 60))
magnet_img = load_image(os.path.join(ASSETS_DIR, "magnet.png"), (40, 40))

# play background music in a loop
try:
    pygame.mixer.music.load(os.path.join(SOUNDS_DIR, "background.mp3"))
    pygame.mixer.music.play(-1)
except pygame.error:
    print("Background music not loaded.")

# diplaying Fonts 
font = pygame.font.SysFont("Arial", 24)
title_font = pygame.font.SysFont("Arial", 48)

#  displaying theme colors for buttons 
BASE_COLOR = (70, 130, 180) # Steel blue for menu buttons
HOVER_COLOR = (100, 180, 220) # color when hover
FEATHER_COLOR = (255, 215, 0)  # Gold color for feathers
PAUSE_COLOR = (255, 255, 255)   # white color  for a pause text

# displaying Buttons
def draw_button(surface, rect, text, base_color, hover_color, font, mouse_pos):
    color = hover_color if rect.collidepoint(mouse_pos) else base_color # detemine button color based on mouse position
    pygame.draw.rect(surface, color, rect, border_radius=8) # buttons are rectangle 
   # render and center text in the button 
    txt_surf = font.render(text, True, (255, 255, 255))
    surface.blit(txt_surf, (rect.centerx - txt_surf.get_width()//2,
                            rect.centery - txt_surf.get_height()//2))

# putting my Splash Screen
def splash_screen():
    start_time = time.time()
    while time.time() - start_time < 3: # it will only show for 3 seconds
        screen.fill((0, 0, 0))
        screen.blit(logo_img, (WIDTH//2 - 40, HEIGHT//2 - 120)) # putting the logo, and center it 
        screen.blit(title_font.render("Bird Migration", True, (255, 255, 255)), (WIDTH//2 - 150, HEIGHT//2 - 40)) # render text on the screen
        screen.blit(font.render("A Game by Bohlokoa", True, (0, 255, 255)), (WIDTH//2 - 120, HEIGHT//2 + 30))
        pygame.display.flip()
        clock.tick(60) # putting a timer to maintain the FPS

#  displaying the Main Menu
def main_menu():
    splash_screen() # the splash screen should display first before main menu
    # the main menu with start, Instructions, and QUIT buttons.
    start_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2, 200, 50) #variable that holds pygame object
    instructions_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 + 70, 200, 50)
    quit_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 + 140, 200, 50)

    running = True
    while running:
        screen.blit(menu_image, (0, 0)) # drawing background png image
        mouse_pos = pygame.mouse.get_pos()  # allowing the game to get mouse coordinates
        # draw all main menu buttons here
        draw_button(screen, start_button, "Start Game", BASE_COLOR, HOVER_COLOR, font, mouse_pos)
        draw_button(screen, instructions_button, "Instructions", BASE_COLOR, HOVER_COLOR, font, mouse_pos)
        draw_button(screen, quit_button, "Quit", BASE_COLOR, HOVER_COLOR, font, mouse_pos)
        pygame.display.update()

     # the game should be able to handle user input 
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit() # know when to exit the game completely
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if start_button.collidepoint(event.pos): # know when input of start game
                    running = False
                elif instructions_button.collidepoint(event.pos): # show instructions
                    show_instructions()
                elif quit_button.collidepoint(event.pos): # Quit the game
                    pygame.quit(); sys.exit() 

#  showing Instructions Screen
def show_instructions():
    back_button = pygame.Rect(WIDTH//2 - 100, HEIGHT - 100, 200, 50)
    running = True
    while running:
        screen.fill((0, 50, 100)) # the color display when showing instructions (blue)
        lines = [
            "1. Arrow keys to move the bird.",
            "2. Collect feathers to grow your tail.",
            "3. Avoid obstacles!",
            "4. Collect power-ups for boosts or freeze.",
            "5. Game gets harder at higher scores.",
            "6. Press P to pause the game."
        ]
        # show each line of instructions with spacing
        for i, line in enumerate(lines):
            screen.blit(font.render(line, True, (255, 255, 255)), (50, 50 + i*40))
         #display the "back" button to the main menu
        mouse_pos = pygame.mouse.get_pos()
        draw_button(screen, back_button, "Back to Menu", BASE_COLOR, HOVER_COLOR, font, mouse_pos)
        pygame.display.flip()
       # be able to handle events within the menu
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if back_button.collidepoint(event.pos):
                    running = False

# displaying the Pause Screen
def pause_screen(): # show the pause screen until user inputs P for play again
    paused = True
    while paused:
        screen.blit(background_img, (0, 0))
    # semi- transparent overlay
        overlay = pygame.Surface((WIDTH, HEIGHT))
        overlay.set_alpha(150)
        overlay.fill((0, 50, 100))
        screen.blit(overlay, (0, 0))
        # showing the pause and resume text
        screen.blit(title_font.render("Paused", True, (255, 255, 0)), (WIDTH//2 - 80, HEIGHT//2 - 20))
        screen.blit(font.render("Press P to Resume", True, (255, 255, 255)), (WIDTH//2 - 90, HEIGHT//2 + 40))
        pygame.display.flip()
         # be able to handle user input for resume and quit 
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_p:
                paused = False

# displaying the Glow Effect around the feather
def draw_glow(surface, position, color=(255, 215, 0), radius=25):
    glow = pygame.Surface((radius*2, radius*2), pygame.SRCALPHA)
    pygame.draw.circle(glow, (*color, 80), (radius, radius), radius)
    surface.blit(glow, (position[0]-radius+15, position[1]-radius+15))

# Game Over Screen
def game_over_screen(score, duration, feathers, powerups): # showing game over and allow user input to restart or quit or go back to main menu
    restart_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 + 70, 200, 50)
    menu_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 + 140, 200, 50)
    quit_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 + 210, 200, 50)

    while True: # displaying s dimmed background
        screen.blit(background_img, (0, 0))
        overlay = pygame.Surface((WIDTH, HEIGHT))
        overlay.set_alpha(120)
        overlay.fill((0, 50, 100))
        screen.blit(overlay, (0, 0))
         # showing game over details / game over menu
        screen.blit(title_font.render("Game Over!", True, (255, 50, 50)), (WIDTH//2 - 120, HEIGHT//2 - 150))
        screen.blit(font.render(f"Score: {score}", True, (255, 255, 255)), (WIDTH//2 - 100, HEIGHT//2 - 90))
        screen.blit(font.render(f"Time: {int(duration)}s", True, (200, 200, 255)), (WIDTH//2 - 100, HEIGHT//2 - 60))
        screen.blit(font.render(f"Feathers: {feathers}", True, FEATHER_COLOR), (WIDTH//2 - 100, HEIGHT//2 - 30))
        screen.blit(font.render(f"Power-ups: {powerups}", True, (0, 255, 255)), (WIDTH//2 - 100, HEIGHT//2))
        # drawing the game over buttons 
        mouse_pos = pygame.mouse.get_pos()
        draw_button(screen, restart_button, "Restart", BASE_COLOR, HOVER_COLOR, font, mouse_pos)
        draw_button(screen, menu_button, "Back to Menu", BASE_COLOR, HOVER_COLOR, font, mouse_pos)
        draw_button(screen, quit_button, "Quit", BASE_COLOR, HOVER_COLOR, font, mouse_pos)
        pygame.display.flip()

# handle user action such as going back to main menu or restart game
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if restart_button.collidepoint(event.pos):
                    return True # restart game
                elif menu_button.collidepoint(event.pos):
                    main_menu() #go back to the main menu
                    return False
                elif quit_button.collidepoint(event.pos):
                    pygame.quit(); sys.exit()

# Main Game Loop
def run_game(): # core gameplay loop where all movement , collision and scoring happen
    score, tail, tail_length = 0, [], 0
    bird_pos = [WIDTH//2, HEIGHT//2] # starting position of where the bird show be exactly
    base_speed = 5
    bird_speed = base_speed
    MAX_SPEED = 8
    SPACING = 15 # distance between tail segments

    # placing the collectible reandomly
    feather_pos = [random.randint(0, WIDTH-30), random.randint(0, HEIGHT-30)]
    powerup_pos = [random.randint(0, WIDTH-30), random.randint(0, HEIGHT-30)]
    freeze_pos = [random.randint(0, WIDTH-30), random.randint(0, HEIGHT-30)]
    # sets up variables to track powerup
    powerup_active = freeze_active = False #no powerups are active at the beginning
    powerup_timer = freeze_timer = 0
    # initial obstacle speed
    obs_speed = 2
    feathers_collected = 0 #how many feathers are collected
    powerups_used = 0 
    start_time = time.time() # be able to track the duration of the gameplay
    # initializing asteroid obstacle
    obstacles = [[random.randint(0, WIDTH-40), random.randint(-300, -40)] for _ in range(3)] # this uses a list comprehension to create a list of obstacles
    magnet_pos = None
    magnet_active = False
    magnet_timer = 0
    asteroids = [] # start game with no asteroids on screen
    asteroid_timer = time.time()

    while True:
         # displaying the Difficulty scaling
        if score < 10:
            difficulty = "Easy"
            obs_speed = 2
            desired_obstacles = 3
            powerup_duration = 5
        elif score < 20:
            difficulty = "Medium"
            obs_speed = 3
            desired_obstacles = 4
            powerup_duration = 5
        else:
            difficulty = "Hard"
            obs_speed = 5
            desired_obstacles = 6
            powerup_duration = 4 # shorter boost time in hard mode

        # maintain obstacle count
        while len(obstacles) < desired_obstacles:
            obstacles.append([random.randint(0, WIDTH-40), random.randint(-300, -40)])
      #display the background first 
        screen.blit(background_img, (0, 0))
        keys = pygame.key.get_pressed()
        # event handling for when using keys
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_p:
                pause_screen()

     # displaying the keys for bird movement
        if keys[pygame.K_LEFT]: bird_pos[0] -= bird_speed
        if keys[pygame.K_RIGHT]: bird_pos[0] += bird_speed
        if keys[pygame.K_UP]: bird_pos[1] -= bird_speed
        if keys[pygame.K_DOWN]: bird_pos[1] += bird_speed
      # prevent bird from moving outside the screen boundaries
        bird_pos[0] = max(0, min(WIDTH-50, bird_pos[0]))
        bird_pos[1] = max(0, min(HEIGHT-50, bird_pos[1]))

    # displaying the tail logic
        if not tail or (abs(bird_pos[0]-tail[0][0]) + abs(bird_pos[1]-tail[0][1])) >= SPACING:
            tail.insert(0, list(bird_pos))
        if len(tail) > tail_length:
            tail.pop()  # if the tail gets too long remove the oldest segment
      #creating rectengles for collisions
        bird_rect = pygame.Rect(bird_pos[0], bird_pos[1], 50, 50)
        feather_rect = feather_img.get_rect(topleft=feather_pos)
        powerup_rect = powerup_img.get_rect(topleft=powerup_pos)
        freeze_rect = freeze_img.get_rect(topleft=freeze_pos)

    # making Obstacles not stay in one place
        for obs_pos in obstacles:
            obs_pos[1] += 0 if freeze_active else obs_speed
            if obs_pos[1] > HEIGHT: # reset when off screen
                obs_pos[1] = -40
                obs_pos[0] = random.randint(0, WIDTH-40)
            obs_rect = pygame.Rect(obs_pos[0], obs_pos[1], 40, 40)

            # if collision meets with obstacle = game over 
            if bird_rect.colliderect(obs_rect):
                duration = time.time() - start_time
                return game_over_screen(score, duration, feathers_collected, powerups_used)
            screen.blit(obstacle_img, obs_pos)

        # Tail self-collision
        if tail_length >= 10:  # collision should only happen after tail gets too long
            for segment in tail[5:]:
                seg_rect = pygame.Rect(segment[0]+10, segment[1]+10, 30, 30)
                 # if the bird touches any of its tail rectangles
                if bird_rect.colliderect(seg_rect):
                    screen.fill((255, 0, 0))
                    pygame.display.flip()
                    pygame.time.delay(300)
                    duration = time.time() - start_time # claculate how long the player survived
                    # end game and go back to the game over menu/screen showing the score, time 
                    return game_over_screen(score, duration, feathers_collected, powerups_used)

        # generating Asteroids 
        if difficulty in ["Hard"]: # appear in hard difficulty 
            if time.time() - asteroid_timer > 2: # check to see if 2 sec have passed since the last asteroid
                asteroids.append([random.randint(0, WIDTH - 60), -60])
                asteroid_timer = time.time() #current time in seconds

         #loops through all asterpids
        for asteroid in asteroids[:]:
            asteroid[1] += 4 if not freeze_active else 0 #moves the asteroid downwards by 4 pixels, unless a freeze power-up is active
            asteroid_rect = pygame.Rect(asteroid[0], asteroid[1], 60, 60)
            screen.blit(asteroid_img, asteroid)
            if bird_rect.colliderect(asteroid_rect):
                duration = time.time() - start_time
                return game_over_screen(score, duration, feathers_collected, powerups_used)
            if asteroid[1] > HEIGHT + 60:
                asteroids.remove(asteroid) # draws the asteroid on the screen

        # feather collection
        if bird_rect.colliderect(feather_rect):
            score += 1  # increase the score by one each time
            feathers_collected += 1  # feather count after each collectible
            tail_length += 1  # increase tail length 
             # the feather is to be moved to a new random poistion after each pickup
            feather_pos = [random.randint(0, WIDTH-30), random.randint(0, HEIGHT-30)]

         # powerup collection (speed boost)
        if bird_rect.colliderect(powerup_rect):
            powerup_active = True # the powerup is active
            powerup_timer = time.time() + powerup_duration # set when boost should end
            bird_speed = min(MAX_SPEED, base_speed*2) # the speed should be kept at a max_speed
            powerups_used += 1 # track how many powerups were used
             # put powerups on random poistion after each pickup
            powerup_pos = [random.randint(0, WIDTH-30), random.randint(0, HEIGHT-30)]

         # (freeze) powerup collection
        if bird_rect.colliderect(freeze_rect):
            freeze_active = True # activate freeze mode
            freeze_timer = time.time() + 5  # last 5 seconds
            # put freeze collectible to a new random poisition after each pickup
            freeze_pos = [random.randint(0, WIDTH-30), random.randint(0, HEIGHT-30)]

        # generating the magnet
        if magnet_pos is None and random.random() < 0.002: #making the magnet rare to find
            magnet_pos = [random.randint(50, WIDTH-90), random.randint(50, HEIGHT-90)]

        if magnet_pos:
            magnet_rect = pygame.Rect(magnet_pos[0], magnet_pos[1], 40, 40)
            if bird_rect.colliderect(magnet_rect): #checks to see if the bird has collided with magnet
                magnet_active = True
                magnet_timer = pygame.time.get_ticks()
                magnet_pos = None #remove megnet from screen
            else: # put the magnet on the screen until collected
                screen.blit(magnet_img, magnet_pos)

     # pulling feather
        if magnet_active: # this part is to run only if the magnet is collected 
            fx, fy =  feather_pos # unpacks the positions of the feather and bird
            bx, by = bird_pos 
            dx, dy = bx - fx, by - fy # distance from feather to bird
            feather_pos[0] += dx * 0.05
            feather_pos[1] += dy * 0.05
            screen.blit(font.render("MAGNET ACTIVE!", True, (255, 255, 0)), (WIDTH//2 - 100, 20))
            if pygame.time.get_ticks() - magnet_timer > 5000: #checks to see if 5 sec have passed since collection 
                magnet_active = False

         # duration control for powerups 
        if powerup_active and time.time() > powerup_timer: #POWERUPS are activated
            powerup_active = False
            bird_speed = base_speed
        if freeze_active and time.time() > freeze_timer:
            freeze_active = False

        # Draw elements for feather
        for segment in tail:
            screen.blit(tail_img, segment)
        draw_glow(screen, feather_pos)
        screen.blit(feather_img, feather_pos)
        screen.blit(powerup_img, powerup_pos)
        screen.blit(freeze_img, freeze_pos)
        screen.blit(bird_img, bird_pos)

         # heads up display
        # put the player information on top of the screen
        # make a semi-transparent background rectangle 
        pygame.draw.rect(screen, (0, 50, 80), (5, 5, 250, 90), border_radius=8)
        screen.blit(font.render(f"Score: {score}", True, (255, 255, 255)), (10, 10))
        screen.blit(font.render(f"Feathers: {tail_length}", True, FEATHER_COLOR), (10, 35))
        screen.blit(font.render(f"Difficulty: {difficulty}", True, (0, 255, 200)), (10, 60))
        screen.blit(font.render("Press P to Pause", True, PAUSE_COLOR), (WIDTH-200, 10))
        
         # show count down for both speed boost and freeze collectible 
        if powerup_active:
            remaining = max(0, int(powerup_timer - time.time()))
            screen.blit(font.render(f"Boost: {remaining}s", True, (0, 255, 255)), (WIDTH - 200, 40))
        if freeze_active:
            remaining = max(0, int(freeze_timer - time.time()))
            screen.blit(font.render(f"Freeze: {remaining}s", True, (0, 200, 255)), (WIDTH - 200, 70))

        # Update the display and maintain FPS
        pygame.display.flip()
        clock.tick(60) # keep the game running at a steady 60 FPS 

# Game Entry Point 
main_menu()
while True:  # run the main gameplay function. if it return false, break the loop and exit
    if not run_game():  # If run_game returns False, exit the loop
        break
pygame.quit() # cleanly close the game window

       
